package com.ct.reactiveprogramming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactiveProgrammingExamleApplicationTests {

	@Test
	void contextLoads() {
	}

}
